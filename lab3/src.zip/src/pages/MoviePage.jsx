import React, { useState } from "react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import MovieCard from "../components/Movie/MovieCard";
import MovieFilter from "../components/Filter/MovieFilter";
import { movies } from "../data/movies";

export default function MoviePage() {
  const [filteredMovies, setFilteredMovies] = useState(movies);

  const handleFilterChange = ({ keyword, genre, sort }) => {
    let result = [...movies];

    // Filter by keyword
    if (keyword) {
      result = result.filter((m) =>
        m.title.toLowerCase().includes(keyword.toLowerCase())
      );
    }

    // Filter by genre
    if (genre && genre !== "All") {
      result = result.filter((m) => m.genre === genre);
    }

    // Sort
    result.sort((a, b) => {
      if (sort === "title") return a.title.localeCompare(b.title);
      if (sort === "year") return b.year - a.year;
      if (sort === "duration") return b.duration - a.duration;
      return 0;
    });

    setFilteredMovies(result);
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">🎬 Movie Collections</h2>
      <MovieFilter onFilterChange={handleFilterChange} />
      <Row xs={1} md={3} className="g-4">
        {filteredMovies.map((movie) => (
          <Col key={movie.id}>
            <MovieCard
              img={movie.poster}
              title={movie.title}
              text={movie.description}
              genre={movie.genre}
              year={movie.year}
              country={movie.country}
              duration={movie.duration}
            />
          </Col>
        ))}
      </Row>
    </div>
  );
}
