import React, { useState } from "react";
import { Tabs, Tab, Form, Button, ProgressBar } from "react-bootstrap";

export default function AccountPage() {
  const [key, setKey] = useState("about");
  const [progress, setProgress] = useState(33);

  const handleSelect = (k) => {
    setKey(k);
    if (k === "about") setProgress(33);
    if (k === "account") setProgress(66);
    if (k === "address") setProgress(100);
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-3">👤 Account Management</h2>
      <ProgressBar now={progress} label={`${progress}%`} className="mb-3" />
      <Tabs activeKey={key} onSelect={handleSelect} className="mb-3" fill>
        <Tab eventKey="about" title="About">
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Full Name</Form.Label>
              <Form.Control type="text" placeholder="Enter your name" />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Birthday</Form.Label>
              <Form.Control type="date" />
            </Form.Group>
          </Form>
        </Tab>

        <Tab eventKey="account" title="Account">
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" placeholder="example@email.com" />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="Enter password" />
            </Form.Group>
          </Form>
        </Tab>

        <Tab eventKey="address" title="Address">
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>City</Form.Label>
              <Form.Control type="text" placeholder="Enter your city" />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Country</Form.Label>
              <Form.Control type="text" placeholder="Enter your country" />
            </Form.Group>
            <Button variant="success">Save Information</Button>
          </Form>
        </Tab>
      </Tabs>
    </div>
  );
}
