import "bootstrap/dist/css/bootstrap.min.css";
import MyNavbar from "./components/Navbar/MyNavbar";
import HomePage from "./pages/HomePage";
import MoviePage from "./pages/MoviePage";
import AccountPage from "./pages/AccountPage";
import FooterPage from "./pages/FooterPage";

function App() {
  return (
    <div>
      <MyNavbar />
      <HomePage />
      <MoviePage />
      <AccountPage />
      <FooterPage />
    </div>
  );
}

export default App;
