import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import { allGenres } from "../../data/movies";

export default function MovieFilter({ onFilterChange }) {
  const [keyword, setKeyword] = useState("");
  const [genre, setGenre] = useState("All");
  const [sort, setSort] = useState("title");

  const handleChange = () => {
    onFilterChange({ keyword, genre, sort });
  };

  return (
    <div className="container mb-4">
      <div className="row g-3 align-items-center">
        <div className="col-md-4">
          <InputGroup>
            <Form.Control
              type="text"
              placeholder="🔍 Search by title..."
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              onKeyUp={handleChange}
            />
          </InputGroup>
        </div>
        <div className="col-md-3">
          <Form.Select
            value={genre}
            onChange={(e) => {
              setGenre(e.target.value);
              handleChange();
            }}
          >
            {allGenres.map((g) => (
              <option key={g}>{g}</option>
            ))}
          </Form.Select>
        </div>
        <div className="col-md-3">
          <Form.Select
            value={sort}
            onChange={(e) => {
              setSort(e.target.value);
              handleChange();
            }}
          >
            <option value="title">Sort by Title</option>
            <option value="year">Sort by Year</option>
            <option value="duration">Sort by Duration</option>
          </Form.Select>
        </div>
      </div>
    </div>
  );
}
