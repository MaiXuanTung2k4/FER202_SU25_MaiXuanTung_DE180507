import React, { useState } from "react";
import {
  Container,
  Row,
  Col,
  Form,
  Button,
  InputGroup,
  Card,
} from "react-bootstrap";
import { FaExclamationCircle } from "react-icons/fa";
import api from "../services/api";
import ConfirmModal from "../components/ConfirmModal";
import { useAuthDispatch } from "../contexts/AuthContext";
import { useNavigate } from "react-router-dom";

const LoginPage = () => {
  const [form, setForm] = useState({ identifier: "", password: "" });
  const [errors, setErrors] = useState({});
  const [modalShow, setModalShow] = useState(false);
  const [modalMsg, setModalMsg] = useState("");
  const dispatch = useAuthDispatch();
  const navigate = useNavigate();

  const validate = () => {
    const e = {};
    if (!form.identifier.trim()) e.identifier = "Username or Email is required.";
    if (!form.password.trim()) e.password = "Password is required.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    try {
      const res = await api.get("/users", { params: { q: form.identifier } });
      const users = res.data.filter(
        (u) => u.username === form.identifier || u.email === form.identifier
      );
      if (users.length === 0 || users[0].password !== form.password) {
        alert("Invalid username/email or password!");
        return;
      }
      const user = users[0];
      dispatch({ type: "LOGIN", payload: user });
      localStorage.setItem("pt_user", JSON.stringify(user));
      setModalMsg(`Welcome, ${user.username}! Login successful.`);
      setModalShow(true);
      setTimeout(() => {
        setModalShow(false);
        navigate("/home");
      }, 1500);
    } catch (err) {
      alert("Login failed. Check JSON server and db.json.");
      console.error(err);
    }
  };

  const handleCancel = () => {
    setForm({ identifier: "", password: "" });
    setErrors({});
  };

  return (
    <Container className="d-flex vh-100 align-items-center justify-content-center bg-light">
      <Row className="w-100">
        <Col md={{ span: 4, offset: 4 }}>
          <Card className="shadow-sm border-0">
            <Card.Header className="text-center bg-light">
              <h5 className="fw-bold m-0">Login</h5>
            </Card.Header>
            <Card.Body>
              <Form onSubmit={handleSubmit}>
                {/* Username or Email */}
                <Form.Group className="mb-3">
                  <Form.Label>Username or email</Form.Label>
                  <InputGroup hasValidation>
                    <Form.Control
                      type="text"
                      name="identifier"
                      placeholder="Enter username or email"
                      value={form.identifier}
                      onChange={handleChange}
                      isInvalid={!!errors.identifier}
                    />
                    {errors.identifier && (
                      <InputGroup.Text className="bg-white text-danger border-danger">
                        <FaExclamationCircle />
                      </InputGroup.Text>
                    )}
                    <Form.Control.Feedback type="invalid">
                      {errors.identifier}
                    </Form.Control.Feedback>
                  </InputGroup>
                </Form.Group>

                {/* Password */}
                <Form.Group className="mb-3">
                  <Form.Label>Password</Form.Label>
                  <InputGroup hasValidation>
                    <Form.Control
                      type="password"
                      name="password"
                      placeholder="Enter password"
                      value={form.password}
                      onChange={handleChange}
                      isInvalid={!!errors.password}
                    />
                    {errors.password && (
                      <InputGroup.Text className="bg-white text-danger border-danger">
                        <FaExclamationCircle />
                      </InputGroup.Text>
                    )}
                    <Form.Control.Feedback type="invalid">
                      {errors.password}
                    </Form.Control.Feedback>
                  </InputGroup>
                </Form.Group>

                {/* Buttons */}
                <div className="d-flex justify-content-between mt-4">
                  <Button
                    type="submit"
                    variant="primary"
                    style={{ width: "48%" }}
                  >
                    Login
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    style={{ width: "48%" }}
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                </div>
              </Form>
            </Card.Body>
          </Card>
          <ConfirmModal
            show={modalShow}
            title="Login Success"
            message={modalMsg}
            onClose={() => setModalShow(false)}
          />
        </Col>
      </Row>
    </Container>
  );
};

export default LoginPage;
