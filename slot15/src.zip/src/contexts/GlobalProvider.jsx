import React, { createContext, useReducer, useEffect } from 'react';
import axios from '../api/axiosConfig';

export const GlobalContext = createContext();

const initialState = { bikes: [], loading: true, error: null };

function reducer(state, action) {
  switch(action.type) {
    case 'SET_BIKES': return { ...state, bikes: action.payload, loading: false };
    case 'UPDATE_BIKE': {
      const updated = state.bikes.map(b => b.id === action.payload.id ? action.payload : b);
      return { ...state, bikes: updated };
    }
    case 'SET_ERROR': return { ...state, error: action.payload, loading: false };
    default: return state;
  }
}

export function GlobalProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    axios.get('/motorbikes')
      .then(res => dispatch({ type: 'SET_BIKES', payload: res.data }))
      .catch(err => dispatch({ type: 'SET_ERROR', payload: err.message }));
  }, []);

  return (
    <GlobalContext.Provider value={{ state, dispatch }}>
      {children}
    </GlobalContext.Provider>
  );
}
