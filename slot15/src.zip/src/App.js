import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import MotorbikeList from './components/MotorbikeList';
import MotorbikeDetail from './components/MotorbikeDetail';
import CartPage from './components/CartPage';
import NotFound from './components/NotFound';
import { GlobalProvider } from './contexts/GlobalProvider';
import { CartProvider } from './contexts/CartProvider';

function App() {
  return (
    <GlobalProvider>
      <CartProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Navigate to="/motorbikes" replace />} />
            <Route path="/login" element={<LoginForm />} />
            <Route path="/motorbikes" element={<MotorbikeList />} />
            <Route path="/view/:id" element={<MotorbikeDetail />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Router>
      </CartProvider>
    </GlobalProvider>
  );
}

export default App;
