import React, { useEffect, useState } from 'react';
import axios from '../api/axiosConfig';
import { useParams, useNavigate } from 'react-router-dom';

export default function MotorbikeDetail() {
  const { id } = useParams();
  const [bike, setBike] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`/motorbikes/${id}`)
      .then(res => setBike(res.data))
      .catch(() => setBike(undefined)); // undefined => not found
  }, [id]);

  if (bike === null) return <div>Loading...</div>;
  if (bike === undefined) return <div>404 Not Found</div>;

  return (
    <div>
      <h2>{bike.brand} {bike.model}</h2>
      <img src={bike.image} alt="" style={{maxWidth:400}}/>
      <p>Year: {bike.year}</p>
      <p>Price: ${bike.price}</p>
      <p>Stock: {bike.stock}</p>
      {/* Add button to add to cart (similar logic to MotorbikeCard) */}
    </div>
  );
}
