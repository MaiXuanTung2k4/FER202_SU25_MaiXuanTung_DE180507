import React, { useContext } from 'react';
import { CartContext } from '../contexts/CartProvider';
import { GlobalContext } from '../contexts/GlobalProvider';
import { Table, Button, Form } from 'react-bootstrap';
import axios from '../api/axiosConfig';

export default function CartPage() {
  const { state: cartState, dispatch: cartDispatch } = useContext(CartContext);
  const { state: globalState, dispatch: globalDispatch } = useContext(GlobalContext);

  const handleUpdateQty = async (id, newQty) => {
    const cartItem = cartState.items.find(i => i.id === id);
    const bike = globalState.bikes.find(b => b.id === id);
    if (!bike) return;
    const delta = newQty - cartItem.qty;
    if (delta > bike.stock) return alert('Not enough stock');
    // Update server stock
    const updatedStock = bike.stock - delta;
    await axios.patch(`/motorbikes/${id}`, { stock: updatedStock });
    globalDispatch({ type: 'UPDATE_BIKE', payload: { ...bike, stock: updatedStock }});
    cartDispatch({ type: 'UPDATE_QTY', payload: { id, qty: newQty }});
  };

  const handleRemove = async (id) => {
    const cartItem = cartState.items.find(i => i.id === id);
    const bike = globalState.bikes.find(b => b.id === id);
    if (!bike) return;
    // restore stock on server
    const restoredStock = bike.stock + cartItem.qty;
    await axios.patch(`/motorbikes/${id}`, { stock: restoredStock });
    globalDispatch({ type: 'UPDATE_BIKE', payload: { ...bike, stock: restoredStock }});
    cartDispatch({ type: 'REMOVE_FROM_CART', payload: id });
  };

  const total = cartState.items.reduce((s,i)=>s + i.subtotal, 0);

  return (
    <div>
      <h2>Cart</h2>
      <Table>
        <thead><tr><th>Title</th><th>Qty</th><th>Subtotal</th><th>Action</th></tr></thead>
        <tbody>
          {cartState.items.map(i => (
            <tr key={i.id}>
              <td>{i.title}</td>
              <td>
                <Form.Control type="number" value={i.qty} min={1}
                  onChange={(e)=>handleUpdateQty(i.id, Number(e.target.value))} style={{width:80}}/>
              </td>
              <td>{i.subtotal}</td>
              <td><Button variant="danger" onClick={()=>handleRemove(i.id)}>Remove</Button></td>
            </tr>
          ))}
        </tbody>
      </Table>
      <h4>Total: ${total}</h4>
    </div>
  );
}
