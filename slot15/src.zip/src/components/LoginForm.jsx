import React, { useState } from 'react';
import PropTypes from 'prop-types';
import axios from '../api/axiosConfig';
import { Form, Button, Modal, Alert } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

export default function LoginForm({ setUser }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [alertMsg, setAlertMsg] = useState('');
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.get(`/users?username=${username}&password=${password}`);
      if (res.data && res.data.length > 0) {
        setUser(username); // gọi hàm từ prop
        setShowModal(true);
        setTimeout(() => {
          setShowModal(false);
          navigate('/motorbikes');
        }, 1200);
      } else {
        setAlertMsg('Invalid username or password!');
      }
    } catch (err) {
      setAlertMsg('Error contacting server');
    }
  };

  const handleCancel = () => {
    setUsername('');
    setPassword('');
    setAlertMsg('');
  };

  return (
    <>
      <Form onSubmit={handleLogin}>
        {alertMsg && <Alert variant="danger">{alertMsg}</Alert>}
        <Form.Group className="mb-3">
          <Form.Label>Username</Form.Label>
          <Form.Control value={username} onChange={e=>setUsername(e.target.value)} required />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Password</Form.Label>
          <Form.Control type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        </Form.Group>
        <Button type="submit">Login</Button>{' '}
        <Button variant="secondary" onClick={handleCancel}>Cancel</Button>
      </Form>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Body>Welcome, {username} login successful!</Modal.Body>
      </Modal>
    </>
  );
}

LoginForm.propTypes = {
  setUser: PropTypes.func.isRequired,
  // username/password fields validation is enforced in component state and required attribute.
};
