import React, { useContext, useState, useMemo } from 'react';
import { GlobalContext } from '../contexts/GlobalProvider';
import MotorbikeCard from './MotorbikeCard';
import { Form, Row, Col } from 'react-bootstrap';

export default function MotorbikeList() {
  const { state } = useContext(GlobalContext);
  const [q, setQ] = useState('');
  const [sort, setSort] = useState('none');

  const filtered = useMemo(() => {
    let list = state.bikes || [];
    if (q) list = list.filter(b => b.model.toLowerCase().includes(q.toLowerCase()));
    if (sort === 'asc') list = [...list].sort((a,b)=>a.price-b.price);
    if (sort === 'desc') list = [...list].sort((a,b)=>b.price-a.price);
    return list;
  }, [state.bikes, q, sort]);

  if (state.loading) return <div>Loading...</div>;
  if (state.error) return <div>Error: {state.error}</div>;

  return (
    <div>
      <Row className="mb-3">
        <Col md={6}><Form.Control placeholder="Search by model" value={q} onChange={e=>setQ(e.target.value)} /></Col>
        <Col md={3}>
          <Form.Select value={sort} onChange={e=>setSort(e.target.value)}>
            <option value="none">Sort by price</option>
            <option value="asc">Lowest to highest</option>
            <option value="desc">Highest to lowest</option>
          </Form.Select>
        </Col>
      </Row>
      <div className="d-flex flex-wrap">
        {filtered.map(b => <MotorbikeCard bike={b} key={b.id} />)}
      </div>
    </div>
  );
}
