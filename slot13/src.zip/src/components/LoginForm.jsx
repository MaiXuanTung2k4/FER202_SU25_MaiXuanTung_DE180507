import React, { useReducer } from "react";
import { useAuth } from "../contexts/AuthContext";

const initialState = { username: "", password: "" };

function reducer(state, action) {
  switch (action.type) {
    case "SET_FIELD":
      return { ...state, [action.field]: action.value };
    case "RESET":
      return initialState;
    default:
      return state;
  }
}

export default function LoginForm() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { user, isAuthenticated, error, login, logout } = useAuth();

  const handleSubmit = (e) => {
    e.preventDefault();
    login(state.username, state.password);
  };

  return (
    <div
      style={{
        width: "350px",
        margin: "30px auto",
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "20px",
      }}
    >
      <h3>Đăng Nhập (Admin Only)</h3>

      {!isAuthenticated ? (
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "10px" }}>
            <label>Tên đăng nhập:</label>
            <input
              type="text"
              value={state.username}
              onChange={(e) =>
                dispatch({ type: "SET_FIELD", field: "username", value: e.target.value })
              }
              style={{ width: "100%", padding: "8px", marginTop: "4px" }}
            />
          </div>

          <div style={{ marginBottom: "10px" }}>
            <label>Mật khẩu:</label>
            <input
              type="password"
              value={state.password}
              onChange={(e) =>
                dispatch({ type: "SET_FIELD", field: "password", value: e.target.value })
              }
              style={{ width: "100%", padding: "8px", marginTop: "4px" }}
            />
          </div>

          {error && <p style={{ color: "red" }}>{error}</p>}

          <button
            type="submit"
            style={{
              width: "100%",
              padding: "10px",
              background: "#007bff",
              color: "#fff",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Đăng Nhập
          </button>
        </form>
      ) : (
        <div style={{ textAlign: "center" }}>
          <h4>Xin chào, {user.username} 👋</h4>
          <p>Vai trò: {user.role}</p>
          <button
            onClick={logout}
            style={{
              background: "red",
              color: "white",
              border: "none",
              padding: "10px 20px",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Đăng Xuất
          </button>
        </div>
      )}
    </div>
  );
}
