import React from 'react';
import { Navbar, Container, Button } from 'react-bootstrap';
import { useAuth } from '../contexts/AuthContext';

const Header = () => {
  const { user, logout } = useAuth();

  return (
    <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand>🎞️ Movie System</Navbar.Brand>
        <Navbar.Text className="text-white ms-auto">
          {user ? (
            <>
              Xin chào, <strong>{user.fullname}</strong> &nbsp;
              <Button variant="outline-light" size="sm" onClick={logout}>Đăng xuất</Button>
            </>
          ) : (
            <span>Chưa đăng nhập</span>
          )}
        </Navbar.Text>
      </Container>
    </Navbar>
  );
};

export default Header;
