// src/pages/dashboard/DashboardHome.jsx
import React from "react";

export default function DashboardHome() {
  return (
    <div>
      <h2>Dashboard Home</h2>
      <p>Chào mừng đến trang quản trị.</p>
    </div>
  );
}
