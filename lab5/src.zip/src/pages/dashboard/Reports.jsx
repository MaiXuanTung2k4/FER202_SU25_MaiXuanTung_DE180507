// src/pages/dashboard/Reports.jsx
import React from "react";

export default function Reports() {
  return (
    <div>
      <h2>Reports</h2>
      <p>Thống kê và báo cáo.</p>
    </div>
  );
}
