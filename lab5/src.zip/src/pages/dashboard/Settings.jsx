// src/pages/dashboard/Settings.jsx
import React from "react";

export default function Settings() {
  return (
    <div>
      <h2>Settings</h2>
      <p>Tùy chỉnh hệ thống ở đây.</p>
    </div>
  );
}
