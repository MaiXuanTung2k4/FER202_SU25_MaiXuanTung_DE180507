import React from "react";

export default function Home() {
  return (
    <div>
      <h2>Trang Chủ</h2>
      <p>Chào mừng bạn đến với website React đầu tiên của bạn!</p>
    </div>
  );
}
