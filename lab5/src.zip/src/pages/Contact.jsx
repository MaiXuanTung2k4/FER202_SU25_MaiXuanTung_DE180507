import React from "react";

export default function Contact() {
  return (
    <div>
      <h2>Trang Liên Hệ</h2>
      <p>Liên hệ với chúng tôi qua email: contact@example.com</p>
    </div>
  );
}
