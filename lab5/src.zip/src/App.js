// src/App.js
import React from "react";
import { Routes, Route, Link } from "react-router-dom";

import Home from "./pages/Home";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";

import DashboardLayout from "./pages/dashboard/DashboardLayout";
import DashboardHome from "./pages/dashboard/DashboardHome";
import Settings from "./pages/dashboard/Settings";
import Reports from "./pages/dashboard/Reports";

export default function App() {
  return (
    <>
      <nav style={{ display: "flex", gap: 20, padding: 20 }}>
        <Link to="/">Home</Link>
        <Link to="/san-pham">Sản phẩm</Link>
        <Link to="/lien-he">Liên hệ</Link>
        <Link to="/dashboard">Dashboard</Link>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/lien-he" element={<Contact />} />

        {/* Bài 2 */}
        <Route path="/san-pham" element={<Products />} />
        <Route path="/san-pham/:productId" element={<ProductDetail />} />

        {/* Bài 3 */}
        <Route path="/dashboard" element={<DashboardLayout />}>
          <Route index element={<DashboardHome />} />
          <Route path="settings" element={<Settings />} />
          <Route path="reports" element={<Reports />} />
        </Route>

        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}
